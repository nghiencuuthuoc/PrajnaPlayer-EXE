@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "VENV_DIR=.venv_build_win_single"
set "ENTRY="
set "APP_NAME="
set "ICO_PATH="
set "PNG_PATH="
set "VLC_ARGS="
set "DIST_DIR=dist_single"
set "BUILD_DIR=build_single"
set "SPEC_DIR=spec_single"
set "RELEASE_DIR=release_single"
set "FINAL_EXE="

echo ==========================================================
echo PrajnaPlayer Windows Builder - Single EXE Output Only
echo ==========================================================
echo 1. PrajnaPlayer_v19_dualsub_color_speed.py
echo 2. PrajnaPlayer_Dual_Subtitle_v3_state_resume.py
echo.
set /p CHOICE=Choose app [1/2] : 
if "%CHOICE%"=="2" (
    set "ENTRY=PrajnaPlayer_Dual_Subtitle_v3_state_resume.py"
    set "APP_NAME=PrajnaPlayer_Dual_Subtitle_v3"
) else (
    set "ENTRY=PrajnaPlayer_v19_dualsub_color_speed.py"
    set "APP_NAME=PrajnaPlayer_v19"
)

call :find_icon_ico
call :find_icon_png
call :detect_vlc

if not exist "%ENTRY%" (
    echo [ERROR] Entry script not found: %ENTRY%
    exit /b 1
)

echo [INFO] Entry      = %ENTRY%
echo [INFO] App name   = %APP_NAME%
echo [INFO] EXE icon   = %ICO_PATH%
echo [INFO] Window png = %PNG_PATH%
echo [INFO] VLC args   = %VLC_ARGS%

echo.
echo [STEP] Create virtual environment
where py >nul 2>nul
if %errorlevel%==0 (
    py -m venv "%VENV_DIR%"
) else (
    python -m venv "%VENV_DIR%"
)
if not exist "%VENV_DIR%\Scripts\activate.bat" (
    echo [ERROR] Cannot create virtual environment.
    exit /b 1
)
call "%VENV_DIR%\Scripts\activate.bat"

python -m pip install --upgrade pip
if errorlevel 1 goto :fail
pip install -r requirements.txt
if errorlevel 1 goto :fail

if exist "%DIST_DIR%" rmdir /s /q "%DIST_DIR%"
if exist "%BUILD_DIR%" rmdir /s /q "%BUILD_DIR%"
if exist "%SPEC_DIR%" rmdir /s /q "%SPEC_DIR%"
mkdir "%DIST_DIR%" >nul 2>nul
mkdir "%BUILD_DIR%" >nul 2>nul
mkdir "%SPEC_DIR%" >nul 2>nul
mkdir "%RELEASE_DIR%" >nul 2>nul

set "PYI_CMD=pyinstaller --noconfirm --clean --windowed --onefile --distpath %DIST_DIR% --workpath %BUILD_DIR% --specpath %SPEC_DIR% --name %APP_NAME%"
if defined ICO_PATH if exist "%ICO_PATH%" set "PYI_CMD=!PYI_CMD! --icon "%ICO_PATH%" --add-data "%ICO_PATH%;.""
if defined PNG_PATH if exist "%PNG_PATH%" set "PYI_CMD=!PYI_CMD! --add-data "%PNG_PATH%;.""
if defined VLC_ARGS set "PYI_CMD=!PYI_CMD! !VLC_ARGS!"
set "PYI_CMD=!PYI_CMD! "%ENTRY%""

echo.
echo [STEP] Build single EXE
echo !PYI_CMD!
call !PYI_CMD!
if errorlevel 1 goto :fail

set "FINAL_EXE=%RELEASE_DIR%\%APP_NAME%.exe"
copy /y "%DIST_DIR%\%APP_NAME%.exe" "%FINAL_EXE%" >nul
if not exist "%FINAL_EXE%" (
    echo [ERROR] Final EXE not found: %FINAL_EXE%
    goto :fail
)

echo.
echo [STEP] Open test EXE
start "" "%FINAL_EXE%"
timeout /t 5 /nobreak >nul
taskkill /F /IM "%APP_NAME%.exe" >nul 2>nul

echo.
echo [STEP] Cleanup helper data automatically
call :cleanup_helper

echo.
echo [DONE] Single EXE created here:
echo %FINAL_EXE%
echo.
echo [NOTE] This is still a PyInstaller onefile EXE.
echo [NOTE] VLC can be packed inside and extracted to a temp folder at runtime.
goto :after_build

:fail
echo.
echo [ERROR] Build failed.
set /p KEEP_HELPER=Keep helper data for debugging ^(build/spec/dist/venv^)? [y/N] : 
if /I "%KEEP_HELPER%"=="Y" goto :after_build
if /I "%KEEP_HELPER%"=="YES" goto :after_build
call :cleanup_helper

:after_build
set /p DO_CLEAN_RELEASE=Delete release_single folder too ^(only if you do not need the EXE^)? [y/N] : 
if /I "%DO_CLEAN_RELEASE%"=="Y" if exist "%RELEASE_DIR%" rmdir /s /q "%RELEASE_DIR%"
if /I "%DO_CLEAN_RELEASE%"=="YES" if exist "%RELEASE_DIR%" rmdir /s /q "%RELEASE_DIR%"

echo Done.
exit /b 0

:cleanup_helper
if exist "%VENV_DIR%" rmdir /s /q "%VENV_DIR%"
if exist "%BUILD_DIR%" rmdir /s /q "%BUILD_DIR%"
if exist "%DIST_DIR%" rmdir /s /q "%DIST_DIR%"
if exist "%SPEC_DIR%" rmdir /s /q "%SPEC_DIR%"
for /d /r %%D in (__pycache__) do if exist "%%D" rmdir /s /q "%%D"
exit /b 0

:find_icon_ico
set "ICO_PATH="
for %%P in ("..\nct_logo.ico" ".\nct_logo.ico" "..\..\nct_logo.ico" "..\..\..\nct_logo.ico" "..\..\..\..\nct_logo.ico") do (
    if not defined ICO_PATH if exist %%~P set "ICO_PATH=%%~fP"
)
exit /b 0

:find_icon_png
set "PNG_PATH="
for %%P in ("..\nct_logo.png" ".\nct_logo.png" "..\..\nct_logo.png" "..\..\..\nct_logo.png" "..\..\..\..\nct_logo.png") do (
    if not defined PNG_PATH if exist %%~P set "PNG_PATH=%%~fP"
)
exit /b 0

:detect_vlc
set "VLC_ARGS="
set "VLC_DIR="
if exist "%ProgramFiles%\VideoLAN\VLC\libvlc.dll" set "VLC_DIR=%ProgramFiles%\VideoLAN\VLC"
if not defined VLC_DIR if exist "%ProgramFiles(x86)%\VideoLAN\VLC\libvlc.dll" set "VLC_DIR=%ProgramFiles(x86)%\VideoLAN\VLC"
if defined VLC_DIR (
    set "VLC_ARGS=--add-binary "%VLC_DIR%\libvlc.dll;." --add-binary "%VLC_DIR%\libvlccore.dll;." --add-data "%VLC_DIR%\plugins;plugins""
)
exit /b 0
