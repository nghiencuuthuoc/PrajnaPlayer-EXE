# PrajnaPlayer Build Kit

This package contains two Tk + VLC desktop apps and cross-platform build scripts.

Included entry scripts:
- `PrajnaPlayer_v19_dualsub_color_speed.py`
- `PrajnaPlayer_Dual_Subtitle_v3_state_resume.py`

Included helper:
- `prajna_packaging_runtime.py`

## Icon behavior
Runtime window icons search these locations, preferring `../` first:
- `../nct_logo.ico`, `../nct_logo.png`
- `./nct_logo.ico`, `./nct_logo.png`
- `../../nct_logo.ico`, `../../nct_logo.png`
- `../../../nct_logo.ico`, `../../../nct_logo.png`
- `../../../../nct_logo.ico`, `../../../../nct_logo.png`

Windows EXE build prefers `../nct_logo.ico` for the executable icon.
Runtime Tk window prefers `../nct_logo.png` for the window icon.

## Notes
- On Windows, the helper calls `SetCurrentProcessExplicitAppUserModelID(...)` and also forces native big/small icons using `WM_SETICON`.
- The build scripts try to detect local VLC runtime and bundle it when possible.
- If VLC is not auto-detected, install desktop VLC on the target machine.
- macOS app icon ideally uses `.icns`; the script tries to generate it from `nct_logo.png` automatically.

## Build outputs
- Windows: `dist/<AppName>.exe`
- macOS: `dist/<AppName>.app`
